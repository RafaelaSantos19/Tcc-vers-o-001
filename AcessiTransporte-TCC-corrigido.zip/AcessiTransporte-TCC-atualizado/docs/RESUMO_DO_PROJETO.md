# Resumo do Projeto Final

## Projeto

O projeto é o **AcessiTransporte**, um sistema de transporte acessível para pessoas com deficiência ou mobilidade reduzida.

## Problema

Pessoas com deficiência enfrentam barreiras no uso de aplicativos de transporte convencionais, como falta de veículos adaptados, motoristas preparados e interfaces acessíveis.

## Solução

O sistema oferece um front-end acessível e uma API REST para gerenciar usuários, corridas e solicitações de atendimento.

## Tecnologias

- NestJS
- TypeScript
- Prisma ORM
- SQLite
- Jest
- Supertest
- HTML, CSS e JavaScript no front-end

## Arquitetura

Arquitetura em camadas: Controller, Service, DTOs e persistência com Prisma.

## Operações implementadas

- Criação de dados;
- Consulta de dados;
- Atualização parcial;
- Exclusão de dados.

## Link do GitHub

https://github.com/RafaelaSantos19/Tcc
