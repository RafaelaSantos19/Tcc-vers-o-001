import { IsEmail, IsOptional, IsString } from 'class-validator';
export class UpdateUserDto { @IsString() @IsOptional() nome?:string; @IsEmail() @IsOptional() email?:string; @IsString() @IsOptional() telefone?:string; @IsString() @IsOptional() tipo?:string; }
