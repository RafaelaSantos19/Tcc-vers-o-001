import { IsEmail, IsNotEmpty, IsOptional, IsString } from 'class-validator';
export class CreateUserDto { @IsString() @IsNotEmpty() nome:string; @IsEmail() email:string; @IsString() @IsOptional() telefone?:string; @IsString() @IsOptional() tipo?:string; }
