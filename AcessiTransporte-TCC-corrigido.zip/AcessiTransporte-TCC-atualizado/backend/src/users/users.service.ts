import { Injectable, NotFoundException } from '@nestjs/common';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { UsersRepository } from './users.repository';
@Injectable()
export class UsersService { constructor(private repo:UsersRepository){} create(dto:CreateUserDto){return this.repo.create(dto);} findAll(){return this.repo.findAll();} async findOne(id:number){const user=await this.repo.findOne(id); if(!user) throw new NotFoundException('Usuário não encontrado.'); return user;} async update(id:number,dto:UpdateUserDto){await this.findOne(id); return this.repo.update(id,dto);} async remove(id:number){await this.findOne(id); await this.repo.remove(id); return {message:'Usuário removido com sucesso.'};} }
