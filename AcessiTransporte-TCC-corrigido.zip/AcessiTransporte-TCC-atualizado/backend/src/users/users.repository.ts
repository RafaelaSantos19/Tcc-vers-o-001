import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
@Injectable()
export class UsersRepository { constructor(private prisma:PrismaService){} create(data:CreateUserDto){return this.prisma.user.create({data});} findAll(){return this.prisma.user.findMany({orderBy:{id:'asc'}});} findOne(id:number){return this.prisma.user.findUnique({where:{id}});} update(id:number,data:UpdateUserDto){return this.prisma.user.update({where:{id},data});} remove(id:number){return this.prisma.user.delete({where:{id}});} }
