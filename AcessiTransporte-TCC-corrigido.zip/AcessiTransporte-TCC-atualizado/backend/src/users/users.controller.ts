import { Body, Controller, Delete, Get, Param, Patch, Post } from '@nestjs/common';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { UsersService } from './users.service';
@Controller('users')
export class UsersController { constructor(private service:UsersService){} @Post() create(@Body() dto:CreateUserDto){return this.service.create(dto);} @Get() findAll(){return this.service.findAll();} @Get(':id') findOne(@Param('id') id:string){return this.service.findOne(Number(id));} @Patch(':id') update(@Param('id') id:string,@Body() dto:UpdateUserDto){return this.service.update(Number(id),dto);} @Delete(':id') remove(@Param('id') id:string){return this.service.remove(Number(id));} }
