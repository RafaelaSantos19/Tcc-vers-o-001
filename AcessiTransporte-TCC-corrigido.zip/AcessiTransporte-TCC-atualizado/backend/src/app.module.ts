import { Module } from '@nestjs/common';
import { PrismaModule } from './prisma/prisma.module';
import { UsersModule } from './users/users.module';
import { RidesModule } from './rides/rides.module';
import { SacModule } from './sac/sac.module';
@Module({ imports:[PrismaModule, UsersModule, RidesModule, SacModule] })
export class AppModule {}
